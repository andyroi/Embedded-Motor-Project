/*
 * Copyright 2016-2024 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file    Build Robot Motors.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL46Z4.h"
#include "fsl_debug_console.h"
/* TODO: insert other include files here. */

/* TODO: insert other definitions and declarations here. */

/*
 * @brief   Application entry point.
 */
void longestdelay()
{
	delay(1000);
	delay(1000);
	delay(1000);
	delay(1000);
	delay(1000);
	delay(120); //325
}

void longerdelay()
{
	delay(1000);
	delay(1000);
	return;
}

void rotationdelay()
{
	delay(1000);
	delay(100);
}

void delay(int m)
{
    SIM->SCGC6 |= (1 << 24); // Clock Enable TPM0
    SIM->SOPT2 |= (0x2 << 24); // Set TPMSRC to OSCERCLK
    TPM0->CONF |= (0x1 << 17); // Stop on Overflow
    TPM0->SC = (0x1 << 7) | (0x07); // Reset Timer Overflow Flag, Set Prescaler 128
    TPM0->MOD = m * 61 + m/2; //

    TPM0->SC |= 0x01 << 3; // Start the clock!

    while(!(TPM0->SC & 0x80)){} // Wait until Overflow Flag
    return;
}

int main(void) {

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    //Blinky tester
//    SIM->SCGC5 |= 1<<12;
//    PORTD->PCR[5] &= ~0x700;
//    PORTD->PCR[5] |= 0x700 & (1 << 8);
//    GPIOD->PDDR |= (1<<5);

    //PTB0 (LEFT MOTOR PART) ln1
    SIM->SCGC5 |= 1<<10;
    PORTB -> PCR[0] &= ~0x700;
    PORTB -> PCR[0] |= 0x700 & (1<<8);
    GPIOB -> PDDR |= (1<<0);
    //PTB1 ln2
    SIM->SCGC5 |= 1<<10;
    PORTB -> PCR[1] &= ~0x700;
    PORTB -> PCR[1] |= 0x700 & (1<<8);
    GPIOB -> PDDR |= (1<<1);
    //PTB2 PWMA
    SIM->SCGC6 |= 1<<26;
    SIM->SCGC5 |= 1<<10;
    PORTB -> PCR[2] &= ~0x700;
    PORTB -> PCR[2] |= 0x300; //ALT3



    //PTC1 (RIGHT MOTOR) ln1
    SIM->SCGC5 |= 1<<11;
    PORTC -> PCR[1] &= ~0x700;
    PORTC -> PCR[1] |= 0x700 & (1<<8);
    GPIOC -> PDDR |= (1<<1);
    //PTC2 ln2
    SIM->SCGC5 |= 1<<11;
    PORTC -> PCR[2] &= ~0x700;
    PORTC -> PCR[2] |= 0x700 & (1<<8);
    GPIOC -> PDDR |= (1<<2);
    //PTB3 PWMB
    SIM->SCGC6 |= 1<<26;
    SIM->SCGC5 |= 1<<10;
    PORTB -> PCR[3] &= ~0x700;
    PORTB -> PCR[3] |= 0x300; //ALT 3 from reference manual

    //SW1 MAKE THE 5 PATTERN
	SIM->SCGC5 |= (1<<11);
	PORTC->PCR[3] &= ~0x703;
	PORTC->PCR[3] |= 0x703 & ((1 << 8) | 0x3);
	GPIOC->PDDR &= ~(1<<3);
    //SW2 PTC12 MAKE THE S PATTERN
	SIM->SCGC5 |= (1<<11);
	PORTC->PCR[12] &= ~0x703;
	PORTC->PCR[12] |= 0x703 & ((1 << 8) | 0x3);
	GPIOC->PDDR &= ~(1<<12);

    //Set up channel 0 & 1 for PWMB
    SIM->SOPT2 |= (0x2 << 24); //OSCERCLK
    TPM2->CONTROLS[0].CnSC |= (0x2 << 2) | (0x2 << 4); //edge the PWM
    TPM2->CONTROLS[1].CnSC |= (0x2 << 2) | (0x2 << 4); //edge the PWM
    TPM2->MOD = 7999;

    TPM2->CONTROLS[0].CnV = 1; //set none zero
    TPM2->CONTROLS[1].CnV = 1;

    TPM2->SC |= 0x01 << 3; //start clock


    while(1) { //B = left motor C = right motor
    	 if(!(GPIOC->PDIR & 0x8)){
        	TPM2->CONTROLS[0].CnV = 5500; //Half duty cycle is MOD/2 50% left
        	TPM2->CONTROLS[1].CnV = 5500; //right

        	//forward
        	GPIOB -> PDOR |= (1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	longerdelay();
        	//stop + rotate
        	GPIOB -> PDOR &= ~(1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2 turning right portion
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	rotationdelay();
        	//forward
        	GPIOB -> PDOR |= (1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	longerdelay();
        	//stop + rotate right motor
        	GPIOB -> PDOR &= ~(1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2 turning right portion
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	rotationdelay();
        	//forward
        	GPIOB -> PDOR |= (1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	longerdelay();
        	//stop + rotate left motor
        	GPIOB -> PDOR |= (1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR &= ~(1<<1); //ln2 turning right portion
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	rotationdelay();
        	//forward
        	GPIOB -> PDOR |= (1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	longerdelay();
        	//stop + rotate left motor
        	GPIOB -> PDOR |= (1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR &= ~(1<<1); //ln2 turning right portion
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	rotationdelay();
        	//forward
        	GPIOB -> PDOR |= (1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	longerdelay();
        	//stop completely
        	GPIOB -> PDOR &= ~(1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR &= ~(1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1

		}
    	if (!(GPIOC->PDIR & 0x1000)) { //2^12 in hex
    		//go forward a bit
        	TPM2->CONTROLS[0].CnV = 4400; //Half duty cycle is MOD/2 50% (this part effects the speed of one of the motors)
        	TPM2->CONTROLS[1].CnV = 4400;
        	GPIOB -> PDOR |= (1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	delay(1000);
    		//top half of S
        	TPM2->CONTROLS[0].CnV = 4500; //Half duty cycle is MOD/2 50% (this part effects the speed of one of the motors)
        	TPM2->CONTROLS[1].CnV = 6600; //right
        	GPIOB -> PDOR |= (1<<1); //ln2  still going forward
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	longestdelay();
        	//bottom half of  S
        	TPM2->CONTROLS[0].CnV = 6600; //Half duty cycle is MOD/2 50% (this part effects the speed of one of the motors)
        	TPM2->CONTROLS[1].CnV = 4500; //right
        	GPIOB -> PDOR |= (1<<1); //ln2  still going forward
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR |= (1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1
        	longestdelay();
        	//stop
        	GPIOB -> PDOR &= ~(1<<1); //ln2
        	GPIOB -> PDOR &= ~(1<<0); //ln1
        	GPIOC -> PDOR &= ~(1<<1); //ln2
        	GPIOC -> PDOR &= ~(1<<2); //ln1
    	 }

    }
    return 0 ;
}
